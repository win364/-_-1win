"use strict";
(self["webpackChunk_1win_frontend_main"] = self["webpackChunk_1win_frontend_main"] || []).push([
    [45842], {
        445842: (t, a, e) => {
            e.r(a), e.d(a, {
                default: () => i
            });
            var r = e(166252);

            function s(t, a) {
                return (0, r.wg)(), (0, r.iD)("svg", (0, r.dG)({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "7",
                    height: "13",
                    viewBox: "0 0 7 13"
                }, t.$attrs), a[0] || (a[0] = [(0, r.uE)('<defs><linearGradient id="cashback-arrow_svg__a" x1="-3.5" y1="-1.69" x2="10.661" y2="4.206" gradientUnits="userSpaceOnUse"><stop stop-color="#6DFEC1"></stop><stop offset=".77" stop-color="#28BC10"></stop></linearGradient></defs><g fill="none" fill-rule="evenodd"><g fill="url(#cashback-arrow_svg__a)" transform="translate(-993 -28)"><g><path d="M996.497 32.333c.528 0 .956.448.956 1v4.253l.916-.96c.373-.39.978-.39 1.351 0s.373 1.024 0 1.414l-2.547 2.667a.926.926 0 01-1.351 0l-2.548-2.667a1.033 1.033 0 01.006-1.408.926.926 0 011.345-.006l.917.96v-4.253c0-.552.428-1 .955-1zm0-4.333c.528 0 .956.448.956 1v.333c0 .553-.428 1-.956 1-.527 0-.955-.447-.955-1V29c0-.552.428-1 .955-1z"></path></g></g></g>', 2)]), 16)
            }
            var n = e(983744);
            const o = {},
                l = (0, n.Z)(o, [
                    ["render", s]
                ]),
                i = l
        }
    }
]);