"use strict";
(self["webpackChunk_1win_frontend_main"] = self["webpackChunk_1win_frontend_main"] || []).push([
    [65525], {
        365525: (n, t, a) => {
            a.r(t), a.d(t, {
                default: () => u
            });
            var e = a(166252);

            function r(n, t) {
                return (0, e.wg)(), (0, e.iD)("svg", (0, e.dG)({
                    viewBox: "0 0 8 5",
                    xmlns: "http://www.w3.org/2000/svg"
                }, n.$attrs), t[0] || (t[0] = [(0, e._)("path", {
                    d: "M1.238 3.957a.75.75 0 11-.976-1.139L2.899.558a1 1 0 011.302 0l2.637 2.26a.75.75 0 01-.976 1.14L3.55 1.974 1.238 3.957z"
                }, null, -1)]), 16)
            }
            var s = a(983744);
            const w = {},
                i = (0, s.Z)(w, [
                    ["render", r]
                ]),
                u = i
        }
    }
]);