"use strict";
(self["webpackChunk_1win_frontend_main"] = self["webpackChunk_1win_frontend_main"] || []).push([
    [73693], {
        873693: (l, e, n) => {
            n.r(e), n.d(e, {
                default: () => u
            });
            var r = n(166252);

            function d(l, e) {
                return (0, r.wg)(), (0, r.iD)("svg", (0, r.dG)({
                    width: "16",
                    height: "16",
                    viewBox: "0 0 16 16",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, l.$attrs), e[0] || (e[0] = [(0, r._)("path", {
                    d: "M10.15 8.264a2.15 2.15 0 11-4.3 0 2.15 2.15 0 014.3 0z",
                    fill: "currentColor"
                }, null, -1), (0, r._)("path", {
                    "fill-rule": "evenodd",
                    "clip-rule": "evenodd",
                    d: "M5.47 4.598a.666.666 0 01-.03.942 3.738 3.738 0 00-.083 5.368.666.666 0 01-.942.942 5.071 5.071 0 01.114-7.281.666.666 0 01.941.029z",
                    fill: "currentColor"
                }, null, -1), (0, r._)("path", {
                    "fill-rule": "evenodd",
                    "clip-rule": "evenodd",
                    d: "M3.251 2.636c.262.259.265.68.006.942a6.668 6.668 0 00-.431 8.891.666.666 0 11-1.035.84A8 8 0 012.31 2.643a.666.666 0 01.942-.006zM10.53 4.598a.666.666 0 00.03.942 3.74 3.74 0 01.083 5.368.666.666 0 10.942.942 5.07 5.07 0 00-.114-7.281.666.666 0 00-.941.029z",
                    fill: "currentColor"
                }, null, -1), (0, r._)("path", {
                    "fill-rule": "evenodd",
                    "clip-rule": "evenodd",
                    d: "M12.749 2.636a.666.666 0 00-.006.942 6.667 6.667 0 01.431 8.891.666.666 0 101.035.84 8 8 0 00-.518-10.667.666.666 0 00-.942-.006z",
                    fill: "currentColor"
                }, null, -1)]), 16)
            }
            var t = n(983744);
            const i = {},
                o = (0, t.Z)(i, [
                    ["render", d]
                ]),
                u = o
        }
    }
]);